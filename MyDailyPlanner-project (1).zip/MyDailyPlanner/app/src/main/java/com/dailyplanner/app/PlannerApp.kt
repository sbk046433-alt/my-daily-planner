package com.dailyplanner.app

import android.app.Application
import com.dailyplanner.app.alarm.Notifier

class PlannerApp : Application() {
    lateinit var settings: Settings
        private set

    override fun onCreate() {
        super.onCreate()
        settings = Settings(this)
        Notifier.ensureChannels(this, settings)
    }
}

val android.content.Context.planner: PlannerApp
    get() = applicationContext as PlannerApp
