@file:OptIn(ExperimentalMaterial3Api::class)

package com.dailyplanner.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.dailyplanner.app.data.Task
import com.dailyplanner.app.util.Bn
import java.time.LocalDate

private val preAlertOptions = listOf(0, 5, 10, 15, 30)

/** নতুন কাজ যোগ বা পুরোনো কাজ সম্পাদনার পূর্ণ পর্দা */
@Composable
fun TaskEditorScreen(
    existing: Task?,
    defaultDay: Long,
    defaultPreAlert: Int,
    onSave: (Task) -> Unit,
    onClose: () -> Unit,
) {
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var desc by remember { mutableStateOf(existing?.description ?: "") }
    var day by remember { mutableLongStateOf(existing?.dateEpochDay ?: defaultDay) }
    var start by remember { mutableIntStateOf(existing?.startMinutes ?: -1) }
    var end by remember { mutableIntStateOf(existing?.endMinutes ?: -1) }
    var alarm by remember { mutableStateOf(existing?.alarmEnabled ?: false) }
    var pre by remember { mutableIntStateOf(existing?.preAlertMinutes ?: defaultPreAlert) }
    var priority by remember { mutableIntStateOf(existing?.priority ?: 2) }
    var error by remember { mutableStateOf<String?>(null) }

    var showDate by remember { mutableStateOf(false) }
    var showStart by remember { mutableStateOf(false) }
    var showEnd by remember { mutableStateOf(false) }

    fun submit() {
        error = when {
            title.isBlank() -> "কাজের নাম লিখুন"
            alarm && start < 0 -> "অ্যালার্মের জন্য শুরুর সময় নির্ধারণ করুন"
            start >= 0 && end >= 0 && end <= start -> "শেষ সময় শুরুর সময়ের পরে হতে হবে"
            else -> null
        }
        if (error != null) return
        val base = existing ?: Task(title = "", dateEpochDay = day)
        onSave(
            base.copy(
                title = title.trim(), description = desc.trim(), dateEpochDay = day,
                startMinutes = start, endMinutes = end,
                alarmEnabled = alarm && start >= 0,
                preAlertMinutes = if (alarm) pre else 0,
                priority = priority
            )
        )
        onClose()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (existing == null) "নতুন কাজ" else "কাজ সম্পাদনা") },
                navigationIcon = {
                    IconButton(onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "পিছনে") }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                title, { title = it }, label = { Text("কাজের নাম") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                desc, { desc = it }, label = { Text("বিস্তারিত বিবরণ") },
                minLines = 3, modifier = Modifier.fillMaxWidth()
            )

            PickerRow("তারিখ", "${Bn.weekday(LocalDate.ofEpochDay(day))}, ${Bn.gregorian(LocalDate.ofEpochDay(day))}") {
                showDate = true
            }
            PickerRow(
                "শুরুর সময়", if (start >= 0) Bn.time(start) else "নির্ধারিত নেই",
                onClear = if (start >= 0) ({ start = -1; alarm = false }) else null
            ) { showStart = true }
            PickerRow(
                "শেষ করার সম্ভাব্য সময়", if (end >= 0) Bn.time(end) else "নির্ধারিত নেই",
                onClear = if (end >= 0) ({ end = -1 }) else null
            ) { showEnd = true }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("অ্যালার্ম / রিমাইন্ডার")
                    Text(
                        "শুরুর সময়ে অ্যালার্ম বাজবে",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = alarm, onCheckedChange = {
                    if (it && start < 0) error = "আগে শুরুর সময় নির্ধারণ করুন" else { alarm = it; error = null }
                })
            }
            if (alarm) {
                Text("আগাম সতর্কবার্তা")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    preAlertOptions.forEach { m ->
                        FilterChip(
                            selected = pre == m, onClick = { pre = m },
                            label = { Text(if (m == 0) "নেই" else "${Bn.num(m)} মি.") }
                        )
                    }
                }
            }

            Text("কাজের গুরুত্ব")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (0..2).forEach { p ->
                    FilterChip(selected = priority == p, onClick = { priority = p }, label = { Text(priorityLabel(p)) })
                }
            }

            error?.let { Text(it, color = Red) }
            Spacer(Modifier.height(4.dp))
            Button(onClick = { submit() }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text(if (existing == null) "কাজ যোগ করুন" else "সংরক্ষণ করুন")
            }
        }
    }

    if (showDate) AppDatePickerDialog(LocalDate.ofEpochDay(day), { showDate = false }) { day = it.toEpochDay() }
    if (showStart) AppTimePickerDialog(start, { showStart = false }) { start = it }
    if (showEnd) AppTimePickerDialog(if (end >= 0) end else if (start >= 0) start + 60 else -1, { showEnd = false }) { end = it }
}

@Composable
private fun PickerRow(label: String, value: String, onClear: (() -> Unit)? = null, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.bodyLarge)
        }
        if (onClear != null) IconButton(onClear) { Icon(Icons.Filled.Close, "মুছুন") }
    }
}
