package com.dailyplanner.app.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import com.dailyplanner.app.MainActivity
import com.dailyplanner.app.data.AppDatabase
import com.dailyplanner.app.data.Task
import java.time.LocalDate
import java.time.ZoneId

object AlarmScheduler {
    const val EXTRA_TASK_ID = "task_id"
    const val EXTRA_PRE = "is_pre"

    fun triggerTime(task: Task): Long =
        LocalDate.ofEpochDay(task.dateEpochDay)
            .atTime(task.startMinutes / 60, task.startMinutes % 60)
            .atZone(ZoneId.systemDefault())
            .toInstant().toEpochMilli()

    private fun alarmIntent(ctx: Context, id: Long, kind: String, pre: Boolean): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).apply {
            data = Uri.parse("planner://alarm/$id/$kind")
            putExtra(EXTRA_TASK_ID, id)
            putExtra(EXTRA_PRE, pre)
        }
        return PendingIntent.getBroadcast(
            ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun canExact(am: AlarmManager) =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()

    fun canScheduleExact(ctx: Context): Boolean =
        canExact(ctx.getSystemService(AlarmManager::class.java))

    private fun setAt(ctx: Context, at: Long, pi: PendingIntent, alarmClock: Boolean) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        try {
            if (canExact(am)) {
                if (alarmClock) {
                    val show = PendingIntent.getActivity(
                        ctx, 0, Intent(ctx, MainActivity::class.java),
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                    am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi)
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                }
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    /** টাস্কের পুরোনো অ্যালার্ম বাতিল করে প্রয়োজনে নতুন সেট করে */
    fun schedule(ctx: Context, task: Task) {
        cancel(ctx, task.id)
        if (task.isDone || !task.alarmEnabled || task.startMinutes < 0) return
        val now = System.currentTimeMillis()
        val at = triggerTime(task)
        if (at > now) setAt(ctx, at, alarmIntent(ctx, task.id, "main", false), true)
        if (task.preAlertMinutes > 0) {
            val preAt = at - task.preAlertMinutes * 60_000L
            if (preAt > now) setAt(ctx, preAt, alarmIntent(ctx, task.id, "pre", true), false)
        }
    }

    fun snooze(ctx: Context, taskId: Long, minutes: Int) {
        val at = System.currentTimeMillis() + minutes * 60_000L
        setAt(ctx, at, alarmIntent(ctx, taskId, "snooze", false), true)
    }

    fun cancel(ctx: Context, taskId: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        for (kind in listOf("main" to false, "pre" to true, "snooze" to false)) {
            val pi = alarmIntent(ctx, taskId, kind.first, kind.second)
            am.cancel(pi)
            pi.cancel()
        }
        Notifier.cancel(ctx, taskId)
    }

    /** রিস্টার্ট/সময় বদলের পর সব ভবিষ্যৎ অ্যালার্ম আবার সেট */
    suspend fun rescheduleAll(ctx: Context) {
        val today = LocalDate.now().toEpochDay()
        AppDatabase.get(ctx).taskDao().pendingAlarms(today).forEach { schedule(ctx, it) }
    }
}
