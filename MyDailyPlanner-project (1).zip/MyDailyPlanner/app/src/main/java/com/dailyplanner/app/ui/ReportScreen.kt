@file:OptIn(ExperimentalMaterial3Api::class)

package com.dailyplanner.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dailyplanner.app.data.Task
import com.dailyplanner.app.util.Bn
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters

@Composable
fun ReportScreen(allTasks: List<Task>) {
    var mode by remember { mutableIntStateOf(0) } // 0 দৈনিক, 1 সাপ্তাহিক, 2 মাসিক
    var anchor by remember { mutableStateOf(LocalDate.now()) }

    val (from, to) = when (mode) {
        0 -> anchor to anchor
        1 -> {
            val s = anchor.with(TemporalAdjusters.previousOrSame(DayOfWeek.SATURDAY))
            s to s.plusDays(6)
        }
        else -> anchor.withDayOfMonth(1) to anchor.withDayOfMonth(1).plusMonths(1).minusDays(1)
    }
    val inRange = allTasks.filter { it.dateEpochDay in from.toEpochDay()..to.toEpochDay() }
    val total = inRange.size
    val done = inRange.count { it.isDone }
    val pending = total - done
    val percent = if (total == 0) 0 else done * 100 / total

    val allDone = allTasks.count { it.isDone }
    val allTotal = allTasks.size

    fun shift(dir: Int) {
        anchor = when (mode) {
            0 -> anchor.plusDays(dir.toLong())
            1 -> anchor.plusWeeks(dir.toLong())
            else -> anchor.plusMonths(dir.toLong())
        }
    }

    val title = when (mode) {
        0 -> Bn.gregorian(from)
        1 -> "${Bn.gregorian(from)} – ${Bn.gregorian(to)}"
        else -> Bn.monthYear(from)
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                listOf("দৈনিক", "সাপ্তাহিক", "মাসিক").forEachIndexed { i, label ->
                    SegmentedButton(
                        selected = mode == i, onClick = { mode = i },
                        shape = SegmentedButtonDefaults.itemShape(i, 3)
                    ) { Text(label) }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton({ shift(-1) }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "আগে") }
                Text(title, Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                IconButton({ shift(1) }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "পরে") }
            }
        }
        item {
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surface)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    ProgressRing(
                        percent, trackColor = MaterialTheme.colorScheme.surfaceVariant,
                        color = Green, textColor = MaterialTheme.colorScheme.onSurface
                    )
                    Row(Modifier.weight(1f).padding(start = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatBox("মোট", total, Blue, Modifier.weight(1f))
                        StatBox("সম্পন্ন", done, Green, Modifier.weight(1f))
                        StatBox("অসম্পন্ন", pending, Orange, Modifier.weight(1f))
                    }
                }
            }
        }
        item {
            Text(
                "সর্বমোট: ${Bn.num(allDone)}টি সম্পন্ন, ${Bn.num(allTotal - allDone)}টি অসম্পন্ন" +
                    if (allTotal > 0) " (${Bn.num(allDone * 100 / allTotal)}%)" else "",
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp
            )
        }
        if (mode == 0) {
            item { SectionTitle("এই দিনের কাজ") }
            if (inRange.isEmpty()) item { Text("কোনো কাজ নেই", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(inRange, key = { it.id }) { t ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (t.isDone) "✔" else "○", color = if (t.isDone) Green else Orange, fontSize = 18.sp)
                    Column(Modifier.padding(start = 10.dp)) {
                        Text(t.title)
                        val sub = buildList {
                            timeRange(t)?.let { add(it) }
                            if (t.isDone && t.completedAt != null) add("সম্পন্ন: ${Bn.timeFromMillis(t.completedAt)}")
                        }.joinToString(" • ")
                        if (sub.isNotEmpty()) Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        } else {
            item { SectionTitle("দিন অনুযায়ী ইতিহাস") }
            val byDay = inRange.groupBy { it.dateEpochDay }.toSortedMap()
            if (byDay.isEmpty()) item { Text("কোনো কাজ নেই", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(byDay.entries.toList(), key = { it.key }) { (epoch, list) ->
                val d = LocalDate.ofEpochDay(epoch)
                val dn = list.count { it.isDone }
                Column(Modifier.fillMaxWidth()) {
                    Row {
                        Text("${Bn.weekday(d)}, ${Bn.num(d.dayOfMonth)} ${Bn.gregorianMonths[d.monthValue - 1]}", Modifier.weight(1f))
                        Text("${Bn.num(dn)}/${Bn.num(list.size)}", color = Green)
                    }
                    LinearProgressIndicator(
                        progress = { dn.toFloat() / list.size },
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                        color = Green, trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }
        }
    }
}
