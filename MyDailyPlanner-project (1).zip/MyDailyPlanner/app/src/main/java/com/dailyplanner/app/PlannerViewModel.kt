package com.dailyplanner.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dailyplanner.app.alarm.AlarmScheduler
import com.dailyplanner.app.data.AppDatabase
import com.dailyplanner.app.data.Task
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class PlannerViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).taskDao()

    val tasks: StateFlow<List<Task>> =
        dao.observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val ctx get() = getApplication<Application>()

    fun save(task: Task) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = if (task.id == 0L) dao.insert(task) else { dao.update(task); task.id }
            AlarmScheduler.schedule(ctx, task.copy(id = id))
        }
    }

    fun delete(task: Task) {
        viewModelScope.launch(Dispatchers.IO) {
            AlarmScheduler.cancel(ctx, task.id)
            dao.deleteById(task.id)
        }
    }

    fun toggle(task: Task) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = if (task.isDone) task.copy(isDone = false, completedAt = null)
            else task.copy(isDone = true, completedAt = System.currentTimeMillis())
            dao.update(updated)
            AlarmScheduler.schedule(ctx, updated)
        }
    }

    /** অন্য দিনের কাজ নতুন দিনে কপি (অসম্পন্ন অবস্থায়) */
    fun copyTo(list: List<Task>, epochDay: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            list.forEach { t ->
                val copy = t.copy(
                    id = 0, dateEpochDay = epochDay, isDone = false,
                    completedAt = null, createdAt = System.currentTimeMillis()
                )
                val id = dao.insert(copy)
                AlarmScheduler.schedule(ctx, copy.copy(id = id))
            }
        }
    }
}
