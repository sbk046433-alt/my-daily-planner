package com.dailyplanner.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class Settings(context: Context) {
    private val prefs = context.getSharedPreferences("planner_settings", Context.MODE_PRIVATE)

    /** 0 = সিস্টেম, 1 = লাইট, 2 = ডার্ক */
    var darkMode by mutableStateOf(prefs.getInt("darkMode", 0))
        private set
    var notificationsEnabled by mutableStateOf(prefs.getBoolean("notif", true))
        private set
    /** খালি = ডিফল্ট অ্যালার্ম শব্দ */
    var soundUri by mutableStateOf(prefs.getString("sound", "") ?: "")
        private set
    var snoozeMinutes by mutableStateOf(prefs.getInt("snooze", 10))
        private set
    var defaultPreAlert by mutableStateOf(prefs.getInt("preAlert", 0))
        private set
    var showBanglaDate by mutableStateOf(prefs.getBoolean("bnDate", true))
        private set
    /** চ্যানেলের শব্দ বদলানো যায় না, তাই শব্দ বদলালে নতুন চ্যানেল (ভার্সন) */
    var channelVersion by mutableStateOf(prefs.getInt("chanVer", 1))
        private set

    fun updateDarkMode(v: Int) { darkMode = v; prefs.edit().putInt("darkMode", v).apply() }
    fun updateNotifications(v: Boolean) { notificationsEnabled = v; prefs.edit().putBoolean("notif", v).apply() }
    fun updateSnooze(v: Int) { snoozeMinutes = v; prefs.edit().putInt("snooze", v).apply() }
    fun updateDefaultPreAlert(v: Int) { defaultPreAlert = v; prefs.edit().putInt("preAlert", v).apply() }
    fun updateShowBangla(v: Boolean) { showBanglaDate = v; prefs.edit().putBoolean("bnDate", v).apply() }
    fun updateSound(uri: String) {
        soundUri = uri
        channelVersion += 1
        prefs.edit().putString("sound", uri).putInt("chanVer", channelVersion).apply()
    }
}
