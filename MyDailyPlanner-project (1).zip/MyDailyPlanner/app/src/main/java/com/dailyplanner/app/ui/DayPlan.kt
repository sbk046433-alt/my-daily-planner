@file:OptIn(ExperimentalMaterial3Api::class)

package com.dailyplanner.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.dailyplanner.app.data.Task
import com.dailyplanner.app.util.Bn
import java.time.LocalDate

class Actions(
    val toggle: (Task) -> Unit,
    val delete: (Task) -> Unit,
    val edit: (Task) -> Unit,
    val add: (Long) -> Unit,
    val copy: (List<Task>, Long) -> Unit,
)

/** একটি দিনের কাজের তালিকা (অসম্পন্ন ও সম্পন্ন আলাদা) */
fun LazyListScope.dayTasks(
    dayTasks: List<Task>,
    actions: Actions,
    onAdd: () -> Unit,
    onCopy: (() -> Unit)?,
    emptyText: String = "এই দিনের জন্য কোনো কাজ নেই",
) {
    item {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onAdd, Modifier.weight(1f)) {
                Icon(Icons.Filled.Add, null)
                Text(" কাজ যোগ করুন")
            }
            if (onCopy != null) {
                OutlinedButton(onCopy, Modifier.weight(1f)) {
                    Icon(Icons.Filled.ContentCopy, null)
                    Text(" অন্য দিন থেকে")
                }
            }
        }
    }
    if (dayTasks.isEmpty()) {
        item {
            Text(
                emptyText,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 24.dp).fillMaxWidth()
            )
        }
        return
    }
    val pending = dayTasks.filter { !it.isDone }
    val done = dayTasks.filter { it.isDone }
    if (pending.isNotEmpty()) {
        item { SectionTitle("অসম্পন্ন (${Bn.num(pending.size)})") }
        items(pending, key = { it.id }) { t ->
            TaskCard(t, { actions.toggle(t) }, { actions.edit(t) }, { actions.delete(t) })
        }
    }
    if (done.isNotEmpty()) {
        item { SectionTitle("সম্পন্ন (${Bn.num(done.size)})") }
        items(done, key = { it.id }) { t ->
            TaskCard(t, { actions.toggle(t) }, { actions.edit(t) }, { actions.delete(t) })
        }
    }
}

/** আগামীকাল / পরশু / যেকোনো তারিখের পরিকল্পনা তৈরির পর্দা */
@Composable
fun DayPlanScreen(
    initialDay: Long,
    allTasks: List<Task>,
    actions: Actions,
    onBack: () -> Unit,
) {
    var day by remember { mutableLongStateOf(initialDay) }
    var showPicker by remember { mutableStateOf(false) }
    var showCopy by remember { mutableStateOf(false) }
    val today = LocalDate.now().toEpochDay()
    val date = LocalDate.ofEpochDay(day)
    val dayList = allTasks.filter { it.dateEpochDay == day }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("পরিকল্পনা: ${Bn.gregorian(date)}") },
                navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "পিছনে") } }
            )
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(day == today, { day = today }, { Text("আজ") })
                    FilterChip(day == today + 1, { day = today + 1 }, { Text("আগামীকাল") })
                    FilterChip(day == today + 2, { day = today + 2 }, { Text("পরশু") })
                    FilterChip(false, { showPicker = true }, { Text("তারিখ বাছুন") })
                }
            }
            item {
                Column {
                    Text(Bn.weekday(date), style = MaterialTheme.typography.titleLarge)
                    Text(
                        "${Bn.gregorian(date)} • ${Bn.banglaDate(date)}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            dayTasks(dayList, actions, onAdd = { actions.add(day) }, onCopy = { showCopy = true })
        }
    }

    if (showPicker) AppDatePickerDialog(date, { showPicker = false }) { day = it.toEpochDay() }
    if (showCopy) CopyFromDayDialog(allTasks, day, actions) { showCopy = false }
}

/** আগের (বা যেকোনো) দিনের কাজ বেছে নতুন দিনে কপি */
@Composable
fun CopyFromDayDialog(allTasks: List<Task>, targetDay: Long, actions: Actions, onDismiss: () -> Unit) {
    var source by remember { mutableLongStateOf(targetDay - 1) }
    var showPicker by remember { mutableStateOf(false) }
    val selected: SnapshotStateList<Long> = remember { mutableStateListOf() }
    val list = allTasks.filter { it.dateEpochDay == source }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("অন্য দিন থেকে কপি") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton({ showPicker = true }, Modifier.fillMaxWidth()) {
                    Text("কোন দিন থেকে: ${Bn.gregorian(LocalDate.ofEpochDay(source))}")
                }
                if (list.isEmpty()) {
                    Text("এই দিনে কোনো কাজ নেই", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    LazyColumn(Modifier.padding(top = 4.dp)) {
                        items(list, key = { it.id }) { t ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(t.id in selected, {
                                    if (it) selected.add(t.id) else selected.remove(t.id)
                                })
                                Column {
                                    Text(t.title)
                                    timeRange(t)?.let {
                                        Text(it, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = selected.isNotEmpty(),
                onClick = {
                    actions.copy(list.filter { it.id in selected }, targetDay)
                    onDismiss()
                }
            ) { Text("কপি করুন") }
        },
        dismissButton = { TextButton(onDismiss) { Text("বাতিল") } }
    )
    if (showPicker) AppDatePickerDialog(LocalDate.ofEpochDay(source), { showPicker = false }) {
        source = it.toEpochDay()
        selected.clear()
    }
}
