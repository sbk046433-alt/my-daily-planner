package com.dailyplanner.app.util

import java.time.LocalDate
import java.time.Year
import java.time.temporal.ChronoUnit

/** বাংলা সংখ্যা, তারিখ, সময় সংক্রান্ত সহায়ক ফাংশন */
object Bn {
    private val digits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')

    val weekdays = listOf("সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার", "রবিবার")

    /** সপ্তাহ শনিবার থেকে শুরু (বাংলাদেশের নিয়ম) */
    val weekdaysShortFromSat = listOf("শনি", "রবি", "সোম", "মঙ্গল", "বুধ", "বৃহ", "শুক্র")

    val gregorianMonths = listOf(
        "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
        "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
    )

    val banglaMonths = listOf(
        "বৈশাখ", "জ্যৈষ্ঠ", "আষাঢ়", "শ্রাবণ", "ভাদ্র", "আশ্বিন",
        "কার্তিক", "অগ্রহায়ণ", "পৌষ", "মাঘ", "ফাল্গুন", "চৈত্র"
    )

    fun num(n: Number): String = num(n.toString())

    fun num(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) sb.append(if (c in '0'..'9') digits[c - '0'] else c)
        return sb.toString()
    }

    fun weekday(d: LocalDate): String = weekdays[d.dayOfWeek.value - 1]

    /** যেমন: ১৯ নভেম্বর ২০২৬ */
    fun gregorian(d: LocalDate): String =
        "${num(d.dayOfMonth)} ${gregorianMonths[d.monthValue - 1]} ${num(d.year)}"

    fun monthYear(d: LocalDate): String = "${gregorianMonths[d.monthValue - 1]} ${num(d.year)}"

    /**
     * সংশোধিত বাংলা পঞ্জিকা (বাংলাদেশ): ১৪ এপ্রিল = ১ বৈশাখ।
     * বৈশাখ–আশ্বিন ৩১ দিন, কার্তিক–মাঘ ও চৈত্র ৩০ দিন, ফাল্গুন ২৯ (লিপ ইয়ারে ৩০)।
     */
    fun banglaDate(d: LocalDate): String {
        val startYear = if (!d.isBefore(LocalDate.of(d.year, 4, 14))) d.year else d.year - 1
        val start = LocalDate.of(startYear, 4, 14)
        var offset = ChronoUnit.DAYS.between(start, d).toInt()
        val leap = Year.isLeap((startYear + 1).toLong())
        val lens = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, if (leap) 30 else 29, 30)
        var m = 0
        while (m < 11 && offset >= lens[m]) {
            offset -= lens[m]
            m++
        }
        return "${num(offset + 1)} ${banglaMonths[m]} ${num(startYear - 593)}"
    }

    private fun period(h: Int): String = when (h) {
        in 4..5 -> "ভোর"
        in 6..11 -> "সকাল"
        in 12..14 -> "দুপুর"
        in 15..17 -> "বিকাল"
        in 18..19 -> "সন্ধ্যা"
        else -> "রাত"
    }

    /** মধ্যরাত থেকে মিনিট -> "সকাল ৮:৩০" */
    fun time(minutes: Int): String {
        val h = (minutes / 60) % 24
        val m = minutes % 60
        val h12 = if (h % 12 == 0) 12 else h % 12
        return "${period(h)} ${num(h12)}:${num(m.toString().padStart(2, '0'))}"
    }

    fun timeFromMillis(millis: Long): String {
        val t = java.time.Instant.ofEpochMilli(millis).atZone(java.time.ZoneId.systemDefault())
        return time(t.hour * 60 + t.minute)
    }
}
