@file:OptIn(ExperimentalMaterial3Api::class)

package com.dailyplanner.app.ui

import android.app.Activity
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.dailyplanner.app.Settings
import com.dailyplanner.app.alarm.Notifier
import com.dailyplanner.app.util.Bn

@Composable
fun SettingsScreen(settings: Settings, onRequestNotif: () -> Unit) {
    val ctx = LocalContext.current

    val soundLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val uri: Uri? = if (Build.VERSION.SDK_INT >= 33)
                res.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            else
                @Suppress("DEPRECATION") res.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            settings.updateSound(uri?.toString() ?: "")
            Notifier.ensureChannels(ctx, settings)
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionTitle("থিম")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("সিস্টেম", "লাইট", "ডার্ক").forEachIndexed { i, l ->
                FilterChip(settings.darkMode == i, { settings.updateDarkMode(i) }, { Text(l) })
            }
        }
        ToggleRow("বাংলা তারিখ দেখান", settings.showBanglaDate) { settings.updateShowBangla(it) }

        HorizontalDivider()
        SectionTitle("নোটিফিকেশন ও অ্যালার্ম")
        ToggleRow("নোটিফিকেশন / অ্যালার্ম চালু", settings.notificationsEnabled) {
            settings.updateNotifications(it)
            if (it) onRequestNotif()
        }
        OutlinedButton(
            onClick = {
                val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                    putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM or RingtoneManager.TYPE_NOTIFICATION)
                    putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "অ্যালার্মের শব্দ")
                    putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                    if (settings.soundUri.isNotEmpty()) {
                        putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(settings.soundUri))
                    }
                }
                soundLauncher.launch(i)
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("অ্যালার্মের শব্দ পরিবর্তন করুন") }

        Text("স্থগিত (Snooze) সময়")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(5, 10, 15, 30).forEach { m ->
                FilterChip(settings.snoozeMinutes == m, { settings.updateSnooze(m) }, { Text("${Bn.num(m)} মি.") })
            }
        }
        Text("নতুন কাজের ডিফল্ট আগাম সতর্কবার্তা")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0, 5, 10, 15, 30).forEach { m ->
                FilterChip(
                    settings.defaultPreAlert == m, { settings.updateDefaultPreAlert(m) },
                    { Text(if (m == 0) "নেই" else "${Bn.num(m)} মি.") }
                )
            }
        }
        Text(
            "কাজ সম্পাদনার সময় প্রতিটি কাজের জন্য আলাদা রিমাইন্ডার ও আগাম সতর্কবার্তা ঠিক করা যায়।",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked, onChange)
    }
}
