@file:OptIn(ExperimentalMaterial3Api::class)

package com.dailyplanner.app.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dailyplanner.app.data.Task
import com.dailyplanner.app.util.Bn
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

/** সবুজ টিক চেকবক্স */
@Composable
fun TickBox(checked: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (checked) Green else Color.Transparent, label = "tick")
    val border = if (checked) Green else MaterialTheme.colorScheme.outline
    Box(
        modifier = Modifier
            .size(30.dp)
            .background(bg, CircleShape)
            .border(2.dp, border, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (checked) Icon(Icons.Filled.Check, contentDescription = "সম্পন্ন", tint = Color.White, modifier = Modifier.size(20.dp))
    }
}

@Composable
fun PriorityChip(priority: Int) {
    val c = priorityColor(priority)
    Box(
        Modifier
            .background(c.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(priorityLabel(priority), color = c, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

fun timeRange(t: Task): String? = when {
    t.startMinutes < 0 -> null
    t.endMinutes >= 0 -> "${Bn.time(t.startMinutes)} – ${Bn.time(t.endMinutes)}"
    else -> Bn.time(t.startMinutes)
}

@Composable
fun TaskCard(
    task: Task,
    onToggle: () -> Unit,
    onClick: () -> Unit,
    onDelete: () -> Unit,
) {
    var confirm by remember { mutableStateOf(false) }
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, if (task.isDone) Green.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TickBox(task.isDone, onToggle)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    task.title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    textDecoration = if (task.isDone) TextDecoration.LineThrough else null,
                    modifier = Modifier.alpha(if (task.isDone) 0.55f else 1f)
                )
                if (task.description.isNotBlank()) {
                    Text(
                        task.description,
                        fontSize = 13.sp,
                        maxLines = 2,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.alpha(if (task.isDone) 0.55f else 1f)
                    )
                }
                Spacer(Modifier.padding(top = 4.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PriorityChip(task.priority)
                    timeRange(task)?.let {
                        Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (task.alarmEnabled && task.startMinutes >= 0) {
                        Icon(Icons.Filled.Alarm, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                    }
                }
                if (task.isDone && task.completedAt != null) {
                    Text(
                        "সম্পন্ন হয়েছে: ${Bn.timeFromMillis(task.completedAt)}",
                        fontSize = 12.sp, color = Green
                    )
                }
            }
            IconButton(onClick = { confirm = true }) {
                Icon(Icons.Filled.Delete, "মুছুন", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("কাজটি মুছে ফেলবেন?") },
            text = { Text("“${task.title}” এবং এর অ্যালার্ম মুছে যাবে।") },
            confirmButton = { TextButton({ confirm = false; onDelete() }) { Text("মুছুন", color = Red) } },
            dismissButton = { TextButton({ confirm = false }) { Text("না") } }
        )
    }
}

@Composable
fun ProgressRing(percent: Int, size: Dp = 110.dp, trackColor: Color, color: Color, textColor: Color) {
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val stroke = 12.dp.toPx()
            val inset = stroke / 2
            val arcSize = Size(this.size.width - stroke, this.size.height - stroke)
            drawArc(trackColor, 0f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(stroke))
            drawArc(
                color, -90f, 360f * percent / 100f, false, Offset(inset, inset), arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round)
            )
        }
        Text("${Bn.num(percent)}%", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = textColor)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = modifier.padding(vertical = 6.dp))
}

@Composable
fun StatBox(label: String, value: Int, color: Color, modifier: Modifier = Modifier) {
    Column(
        modifier
            .background(color.copy(alpha = 0.12f), RoundedCornerShape(14.dp))
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(Bn.num(value), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = color)
        Text(label, fontSize = 12.sp)
    }
}

@Composable
fun AppDatePickerDialog(initial: LocalDate, onDismiss: () -> Unit, onPick: (LocalDate) -> Unit) {
    val state = rememberDatePickerState(
        initialSelectedDateMillis = initial.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
    )
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                state.selectedDateMillis?.let {
                    onPick(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate())
                }
                onDismiss()
            }) { Text("ঠিক আছে") }
        },
        dismissButton = { TextButton(onDismiss) { Text("বাতিল") } }
    ) { DatePicker(state = state) }
}

@Composable
fun AppTimePickerDialog(initialMinutes: Int, onDismiss: () -> Unit, onPick: (Int) -> Unit) {
    val init = if (initialMinutes >= 0) initialMinutes else 9 * 60
    val state = rememberTimePickerState(init / 60, init % 60, is24Hour = false)
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { onPick(state.hour * 60 + state.minute); onDismiss() }) { Text("ঠিক আছে") }
        },
        dismissButton = { TextButton(onDismiss) { Text("বাতিল") } },
        text = { TimePicker(state = state) }
    )
}
