@file:OptIn(ExperimentalMaterial3Api::class)

package com.dailyplanner.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dailyplanner.app.Settings
import com.dailyplanner.app.data.Task
import com.dailyplanner.app.util.Bn
import java.time.LocalDate
import java.time.YearMonth

/** শনিবার = 0 ... শুক্রবার = 6 */
private fun satIndex(d: LocalDate) = (d.dayOfWeek.value + 1) % 7

@Composable
fun CalendarScreen(allTasks: List<Task>, settings: Settings, actions: Actions) {
    val today = LocalDate.now()
    var month by remember { mutableStateOf(YearMonth.from(today)) }
    var selected by remember { mutableLongStateOf(today.toEpochDay()) }
    var showCopy by remember { mutableStateOf(false) }

    val byDay = remember(allTasks) { allTasks.groupBy { it.dateEpochDay } }
    val selDate = LocalDate.ofEpochDay(selected)

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton({ month = month.minusMonths(1) }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "আগের মাস") }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(Bn.monthYear(month.atDay(1)), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    if (settings.showBanglaDate) {
                        val a = Bn.banglaDate(month.atDay(1)).substringAfter(' ')
                        val b = Bn.banglaDate(month.atEndOfMonth()).substringAfter(' ')
                        Text(if (a == b) a else "$a – $b", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                IconButton({ month = month.plusMonths(1) }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "পরের মাস") }
            }
        }
        item {
            Row(Modifier.fillMaxWidth()) {
                Bn.weekdaysShortFromSat.forEach {
                    Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item {
            val first = month.atDay(1)
            val lead = satIndex(first)
            val days = month.lengthOfMonth()
            val rows = (lead + days + 6) / 7
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                for (r in 0 until rows) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        for (c in 0 until 7) {
                            val dayNum = r * 7 + c - lead + 1
                            if (dayNum < 1 || dayNum > days) {
                                Box(Modifier.weight(1f).aspectRatio(0.85f))
                            } else {
                                val date = month.atDay(dayNum)
                                val list = byDay[date.toEpochDay()].orEmpty()
                                DayCell(
                                    dayNum, list.count { it.isDone }, list.size,
                                    isToday = date == today,
                                    isSelected = date.toEpochDay() == selected,
                                    modifier = Modifier.weight(1f)
                                ) { selected = date.toEpochDay() }
                            }
                        }
                    }
                }
            }
        }
        item {
            Column {
                Text("${Bn.weekday(selDate)}, ${Bn.gregorian(selDate)}", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                if (settings.showBanglaDate) {
                    Text(Bn.banglaDate(selDate), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                val l = byDay[selected].orEmpty()
                if (l.isNotEmpty()) {
                    Text(
                        "${Bn.num(l.count { it.isDone })}/${Bn.num(l.size)} টি কাজ সম্পন্ন",
                        color = Green, fontSize = 13.sp
                    )
                }
            }
        }
        dayTasks(
            byDay[selected].orEmpty(), actions,
            onAdd = { actions.add(selected) },
            onCopy = { showCopy = true }
        )
    }
    if (showCopy) CopyFromDayDialog(allTasks, selected, actions) { showCopy = false }
}

@Composable
private fun DayCell(
    day: Int, done: Int, total: Int, isToday: Boolean, isSelected: Boolean,
    modifier: Modifier, onClick: () -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    val bg = when {
        isSelected -> primary
        total > 0 && done == total -> Green.copy(alpha = 0.18f)
        else -> MaterialTheme.colorScheme.surface
    }
    val fg = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    Column(
        modifier
            .aspectRatio(0.85f)
            .background(bg, RoundedCornerShape(10.dp))
            .border(if (isToday) 2.dp else 0.dp, if (isToday) primary else bg, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(Bn.num(day), color = fg, fontWeight = FontWeight.SemiBold)
        if (total > 0) {
            Text("${Bn.num(done)}/${Bn.num(total)}", color = if (isSelected) fg else Green, fontSize = 10.sp)
        }
    }
}
