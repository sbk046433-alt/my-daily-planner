package com.dailyplanner.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Green = Color(0xFF2E9E5B)
val Red = Color(0xFFE03131)
val Orange = Color(0xFFF08C00)
val Blue = Color(0xFF4263EB)

private val Light = lightColorScheme(
    primary = Color(0xFF4263EB),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDBE4FF),
    onPrimaryContainer = Color(0xFF1B2A7A),
    secondary = Color(0xFF2E9E5B),
    background = Color(0xFFF6F7FB),
    surface = Color.White,
    surfaceVariant = Color(0xFFEEF0F7),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF91A7FF),
    onPrimary = Color(0xFF0B1A66),
    primaryContainer = Color(0xFF2B3A8C),
    onPrimaryContainer = Color(0xFFDBE4FF),
    secondary = Color(0xFF51CF66),
    background = Color(0xFF101218),
    surface = Color(0xFF1A1D26),
    surfaceVariant = Color(0xFF252936),
)

@Composable
fun PlannerTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}

fun priorityLabel(p: Int) = when (p) {
    0 -> "জরুরি"
    1 -> "গুরুত্বপূর্ণ"
    else -> "সাধারণ"
}

fun priorityColor(p: Int) = when (p) {
    0 -> Red
    1 -> Orange
    else -> Blue
}
