package com.dailyplanner.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/** priority: 0 = জরুরি, 1 = গুরুত্বপূর্ণ, 2 = সাধারণ */
@Entity(tableName = "tasks", indices = [Index("dateEpochDay")])
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val dateEpochDay: Long,
    /** মধ্যরাত থেকে মিনিট; -1 মানে সময় নির্ধারিত নেই */
    val startMinutes: Int = -1,
    val endMinutes: Int = -1,
    val alarmEnabled: Boolean = false,
    /** অ্যালার্মের কত মিনিট আগে সতর্কবার্তা; 0 = নেই */
    val preAlertMinutes: Int = 0,
    val priority: Int = 2,
    val isDone: Boolean = false,
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface TaskDao {
    @Query(
        "SELECT * FROM tasks ORDER BY dateEpochDay, " +
            "CASE WHEN startMinutes < 0 THEN 99999 ELSE startMinutes END, id"
    )
    fun observeAll(): Flow<List<Task>>

    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun get(id: Long): Task?

    @Query(
        "SELECT * FROM tasks WHERE isDone = 0 AND alarmEnabled = 1 " +
            "AND startMinutes >= 0 AND dateEpochDay >= :fromDay"
    )
    suspend fun pendingAlarms(fromDay: Long): List<Task>

    @Insert
    suspend fun insert(task: Task): Long

    @Update
    suspend fun update(task: Task)

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Database(entities = [Task::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "daily_planner.db"
                ).build().also { instance = it }
            }
    }
}
