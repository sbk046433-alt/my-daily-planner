package com.dailyplanner.app.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.dailyplanner.app.data.AppDatabase
import com.dailyplanner.app.planner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

private fun BroadcastReceiver.async(block: suspend () -> Unit) {
    val pending = goAsync()
    CoroutineScope(Dispatchers.IO).launch {
        try {
            block()
        } finally {
            pending.finish()
        }
    }
}

/** নির্ধারিত সময়ে অ্যালার্ম বাজায় */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(AlarmScheduler.EXTRA_TASK_ID, -1)
        val pre = intent.getBooleanExtra(AlarmScheduler.EXTRA_PRE, false)
        if (id < 0) return
        val app = context.applicationContext
        async {
            val task = AppDatabase.get(app).taskDao().get(id) ?: return@async
            if (task.isDone) return@async
            val settings = app.planner.settings
            if (!settings.notificationsEnabled) return@async
            Notifier.show(app, settings, task, pre)
        }
    }
}

/** নোটিফিকেশনের সম্পন্ন / স্থগিত / বাতিল বাটন */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(AlarmScheduler.EXTRA_TASK_ID, -1)
        if (id < 0) return
        val app = context.applicationContext
        val action = intent.action
        async {
            val dao = AppDatabase.get(app).taskDao()
            when (action) {
                Notifier.ACTION_DONE -> {
                    dao.get(id)?.let {
                        dao.update(it.copy(isDone = true, completedAt = System.currentTimeMillis()))
                    }
                    AlarmScheduler.cancel(app, id)
                }
                Notifier.ACTION_SNOOZE -> {
                    Notifier.cancel(app, id)
                    AlarmScheduler.snooze(app, id, app.planner.settings.snoozeMinutes)
                }
                else -> Notifier.cancel(app, id)
            }
        }
    }
}

/** ফোন রিস্টার্ট / অ্যাপ আপডেট / সময় পরিবর্তনের পর অ্যালার্ম পুনরায় সেট */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        async { AlarmScheduler.rescheduleAll(app) }
    }
}
