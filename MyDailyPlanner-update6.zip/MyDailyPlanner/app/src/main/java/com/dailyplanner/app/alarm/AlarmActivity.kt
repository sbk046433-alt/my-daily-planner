package com.dailyplanner.app.alarm

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dailyplanner.app.data.AppDatabase
import com.dailyplanner.app.data.Task
import com.dailyplanner.app.planner
import com.dailyplanner.app.ui.Green
import com.dailyplanner.app.ui.PlannerTheme
import com.dailyplanner.app.ui.priorityLabel
import com.dailyplanner.app.ui.textScaleOf
import com.dailyplanner.app.util.Bn
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** অ্যালার্ম বাজলে লক স্ক্রিনের ওপরেও পুরো পর্দায় কাজের রিমাইন্ডার দেখায় */
class AlarmActivity : ComponentActivity() {
    private var taskId by mutableLongStateOf(-1L)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        taskId = intent.getLongExtra(AlarmScheduler.EXTRA_TASK_ID, -1L)

        val settings = planner.settings
        setContent {
            val dark = when (settings.darkMode) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }
            PlannerTheme(dark, settings.accent, settings.amoled, textScaleOf(settings.textScaleIdx)) {
                Surface(Modifier.fillMaxSize()) {
                    AlarmScreen(taskId, settings.snoozeMinutes) { action -> act(action) }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        taskId = intent.getLongExtra(AlarmScheduler.EXTRA_TASK_ID, -1L)
    }

    private fun act(action: String) {
        sendBroadcast(
            Intent(this, ActionReceiver::class.java).apply {
                this.action = action
                putExtra(AlarmScheduler.EXTRA_TASK_ID, taskId)
            }
        )
        finish()
    }
}

@Composable
private fun AlarmScreen(taskId: Long, snoozeMinutes: Int, onAction: (String) -> Unit) {
    val ctx = LocalContext.current
    var task by remember(taskId) { mutableStateOf<Task?>(null) }
    LaunchedEffect(taskId) {
        task = withContext(Dispatchers.IO) { AppDatabase.get(ctx).taskDao().get(taskId) }
    }
    val t = task
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("⏰ কাজের সময় হয়েছে", fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(20.dp))
        if (t != null) {
            if (t.startMinutes >= 0) {
                Text(Bn.time(t.startMinutes), fontSize = 40.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
            Text(
                t.title, fontSize = 28.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            if (t.description.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    t.description, fontSize = 16.sp, textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(priorityLabel(t.priority), fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            Text("কাজ পাওয়া যায়নি", fontSize = 20.sp)
        }
        Spacer(Modifier.height(40.dp))
        Button(
            onClick = { onAction(Notifier.ACTION_DONE) },
            colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = androidx.compose.ui.graphics.Color.White),
            modifier = Modifier.fillMaxWidth().height(60.dp)
        ) { Text("✔ কাজ সম্পন্ন হয়েছে", fontSize = 18.sp) }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(
            onClick = { onAction(Notifier.ACTION_SNOOZE) },
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("স্থগিত (${Bn.num(snoozeMinutes)} মিনিট পরে)", fontSize = 16.sp) }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(
            onClick = { onAction(Notifier.ACTION_DISMISS) },
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("বন্ধ করুন", fontSize = 16.sp) }
    }
}
