@file:OptIn(ExperimentalMaterial3Api::class)

package com.dailyplanner.app.amol

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dailyplanner.app.ui.Green
import com.dailyplanner.app.ui.SectionTitle
import com.dailyplanner.app.ui.isDarkTheme
import com.dailyplanner.app.util.Bn

private const val MENU = -1
private const val FREE = 3
private const val NAMES_BASE = 10

private class AmolColors(val arabic: Color, val translit: Color, val meaning: Color, val label: Color)

@Composable
private fun amolColors(): AmolColors =
    if (isDarkTheme()) AmolColors(Color(0xFF69DB7C), Color(0xFF91A7FF), Color(0xFFFFB86B), Color(0xFFD0BFFF))
    else AmolColors(Color(0xFF0B6E4F), Color(0xFF1C4ED8), Color(0xFFB4530A), Color(0xFF7048E8))

/** বিভাগভেদে আলাদা রঙ: ফজর = কমলা, নামাজ = সবুজ, ঘুম = নীল */
@Composable
private fun categoryColor(i: Int): Color {
    val dark = isDarkTheme()
    return when (i) {
        0 -> if (dark) Color(0xFFFFA94D) else Color(0xFFE8590C)
        1 -> if (dark) Color(0xFF69DB7C) else Color(0xFF2B8A3E)
        else -> if (dark) Color(0xFF91A7FF) else Color(0xFF4263EB)
    }
}

@Composable
fun AmolScreen() {
    val ctx = LocalContext.current
    val store = remember { AmolStore(ctx) }
    var screen by rememberSaveable { mutableIntStateOf(MENU) }

    // ১০ বা তার বেশি মানে ৯৯ নামের পর্দা (১০ + বিভাগের সূচক)
    BackHandler(enabled = screen != MENU) { screen = if (screen >= NAMES_BASE) screen - NAMES_BASE else MENU }

    when {
        screen == MENU -> AmolMenu(store) { screen = it }
        screen == FREE -> FreeTasbih(store) { screen = MENU }
        screen >= NAMES_BASE -> NamesScreen(amolCategories[screen - NAMES_BASE], screen - NAMES_BASE, store) {
            screen -= NAMES_BASE
        }
        else -> CategoryScreen(
            amolCategories[screen], screen, store,
            onOpenNames = { screen += NAMES_BASE },
            onBack = { screen = MENU }
        )
    }
}

private fun doneCount(cat: AmolCategory, store: AmolStore) =
    cat.items.count { store.get(cat.id, it.id) >= it.count }

@Composable
private fun AmolMenu(store: AmolStore, onOpen: (Int) -> Unit) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("আমলের বই", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(
                "আজকের আমল ও তাসবিহের হিসাব এখানে রাখুন",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        items(amolCategories.size) { i ->
            val cat = amolCategories[i]
            val done = doneCount(cat, store)
            val accent = categoryColor(i)
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onOpen(i) },
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(accent.copy(alpha = 0.14f))
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(cat.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = accent)
                    Text(cat.subtitle, color = MaterialTheme.colorScheme.onSurface, fontSize = 15.sp)
                    LinearProgressIndicator(
                        progress = { done.toFloat() / cat.items.size },
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                        color = accent, trackColor = accent.copy(alpha = 0.2f)
                    )
                    Text(
                        "আজ ${Bn.num(done)}/${Bn.num(cat.items.size)} টি আমল সম্পন্ন",
                        fontSize = 14.sp, color = accent, fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onOpen(FREE) },
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text(
                        "তাসবিহ কাউন্টার", fontSize = 20.sp, fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        "যেকোনো যিকির নিজের মতো গুনুন",
                        color = MaterialTheme.colorScheme.onPrimaryContainer, fontSize = 13.sp
                    )
                }
            }
        }
    }
}

private fun namesCat(cat: AmolCategory) = "${cat.id}_names"

private fun namesRead(cat: AmolCategory, store: AmolStore) =
    asmaulHusna.indices.count { store.get(namesCat(cat), "n$it") > 0 }

@Composable
private fun NamesScreen(cat: AmolCategory, index: Int, store: AmolStore, onBack: () -> Unit) {
    val accent = categoryColor(index)
    val c = amolColors()
    val read = namesRead(cat, store)
    Column(Modifier.fillMaxSize()) {
        TopBackRow("আল্লাহর ৯৯ নাম", onBack)
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(accent.copy(alpha = 0.16f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            "আজ ${Bn.num(read)}/${Bn.num(asmaulHusna.size)} টি নাম পড়া হয়েছে",
                            fontSize = 18.sp, fontWeight = FontWeight.Bold, color = accent
                        )
                        LinearProgressIndicator(
                            progress = { read.toFloat() / asmaulHusna.size },
                            modifier = Modifier.fillMaxWidth(),
                            color = accent, trackColor = accent.copy(alpha = 0.2f)
                        )
                        Text(
                            "হাদিসে এসেছে, আল্লাহর ৯৯টি নাম আছে; যে এগুলো আয়ত্ত করবে (মুখস্থ করে, অর্থ বুঝে ও আমল করে) সে জান্নাতে প্রবেশ করবে (বুখারি ও মুসলিম)। নাম পড়ে শেষ করলে সেটিতে চাপ দিয়ে চিহ্ন দিন।",
                            fontSize = 14.sp, lineHeight = 22.sp
                        )
                        Text(
                            "মূল নাম “আল্লাহ”। এখানে সেটি বাদে তিরমিযিতে বর্ণিত প্রচলিত তালিকার ৯৯টি গুণবাচক নাম দেওয়া হয়েছে। তালিকায় আলেমদের মধ্যে সামান্য মতভেদ আছে।",
                            fontSize = 13.sp, lineHeight = 20.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            items(asmaulHusna.size) { i ->
                val n = asmaulHusna[i]
                val isRead = store.get(namesCat(cat), "n$i") > 0
                Card(
                    modifier = Modifier.fillMaxWidth().clickable {
                        store.set(namesCat(cat), "n$i", if (isRead) 0 else 1)
                    },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        if (isRead) Green.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(44.dp).background(if (isRead) Green else accent, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                if (isRead) "✔" else Bn.num(i + 1),
                                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp
                            )
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                n.arabic, fontSize = 30.sp, lineHeight = 48.sp,
                                fontWeight = FontWeight.Medium, color = c.arabic
                            )
                            Text(n.translit, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = c.translit)
                            Text(n.meaning, fontSize = 17.sp, lineHeight = 25.sp, color = c.meaning)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TopBackRow(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "পিছনে") }
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun CategoryScreen(
    cat: AmolCategory, index: Int, store: AmolStore,
    onOpenNames: () -> Unit, onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        TopBackRow(cat.title, onBack)
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("জেনে রাখুন", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        cat.tips.forEach {
                            Text("• $it", fontSize = 16.sp, lineHeight = 24.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                }
            }
            if (cat.hasNames) {
                item {
                    val accent = categoryColor(index)
                    val read = namesRead(cat, store)
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onOpenNames() },
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(accent.copy(alpha = 0.16f))
                    ) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                "আল্লাহর ৯৯ নাম", fontSize = 22.sp,
                                fontWeight = FontWeight.Bold, color = accent
                            )
                            Text(
                                "আরবি, উচ্চারণ ও অর্থসহ — খুলতে চাপ দিন",
                                fontSize = 15.sp
                            )
                            Text(
                                "আজ ${Bn.num(read)}/${Bn.num(asmaulHusna.size)} টি নাম পড়া হয়েছে",
                                fontSize = 14.sp, color = accent, fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
            items(cat.items, key = { it.id }) { dua ->
                val n = store.get(cat.id, dua.id)
                DuaCard(
                    dua, n,
                    onTap = { if (n < dua.count) store.set(cat.id, dua.id, n + 1) },
                    onAdd = { k -> store.set(cat.id, dua.id, minOf(dua.count, n + k)) },
                    onReset = { store.set(cat.id, dua.id, 0) }
                )
            }
            item {
                Text(
                    "আরবি লেখা ও অনুবাদ নির্ভরযোগ্য আলেম বা বই থেকে মিলিয়ে নেওয়া ভালো।",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun DuaCard(dua: Dua, count: Int, onTap: () -> Unit, onAdd: (Int) -> Unit, onReset: () -> Unit) {
    val done = count >= dua.count
    val c = amolColors()
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(dua.title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Text(
                dua.arabic,
                fontSize = 32.sp, lineHeight = 58.sp,
                fontWeight = FontWeight.Medium,
                color = c.arabic,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Text("উচ্চারণ", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = c.label)
            Text(dua.translit, fontSize = 18.sp, lineHeight = 28.sp, color = c.translit)
            Text("অর্থ", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = c.label)
            Text(dua.meaning, fontSize = 18.sp, lineHeight = 28.sp, color = c.meaning)
            if (dua.note.isNotBlank()) {
                Text(dua.note, fontSize = 14.sp, color = Green, fontWeight = FontWeight.Medium)
            }
            if (dua.source.isNotBlank()) {
                Text("সূত্র: ${dua.source}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = onTap,
                    modifier = Modifier.weight(1f).height(54.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (done) Green else MaterialTheme.colorScheme.primary,
                        contentColor = if (done) Color.White else MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Text(
                        if (done) "✔ সম্পন্ন  ${Bn.num(count)}/${Bn.num(dua.count)}"
                        else "পড়লাম  ${Bn.num(count)}/${Bn.num(dua.count)}",
                        fontSize = 16.sp, fontWeight = FontWeight.Bold
                    )
                }
                IconButton(onReset) { Icon(Icons.Filled.Refresh, "আবার শুরু") }
            }
            // বড় সংখ্যার আমলে (১০০ বা তার বেশি) দ্রুত গণনার বাটন
            if (dua.count >= 100 && !done) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = { onAdd(10) },
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) { Text("+১০", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                    OutlinedButton(
                        onClick = { onAdd(100) },
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) { Text("+১০০", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

@Composable
private fun FreeTasbih(store: AmolStore, onBack: () -> Unit) {
    val cat = "free"
    val count = store.get(cat, "count")
    val target = store.get(cat, "target").let { if (it == 0) 33 else it } // -1 = লক্ষ্য নেই
    val reached = target > 0 && count >= target

    Column(Modifier.fillMaxSize()) {
        TopBackRow("তাসবিহ কাউন্টার", onBack)
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Text("লক্ষ্য", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(33, 99, 100).forEach { t ->
                    FilterChip(target == t, { store.set(cat, "target", t) }, { Text(Bn.num(t)) })
                }
                FilterChip(target == -1, { store.set(cat, "target", -1) }, { Text("সীমাহীন") })
            }
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier
                    .size(230.dp)
                    .background(if (reached) Green else MaterialTheme.colorScheme.primary, CircleShape)
                    .clickable { store.set(cat, "count", count + 1) },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    val fg = if (reached) Color.White else MaterialTheme.colorScheme.onPrimary
                    Text(Bn.num(count), fontSize = 64.sp, fontWeight = FontWeight.Bold, color = fg)
                    Text(
                        if (target > 0) "লক্ষ্য ${Bn.num(target)}" else "চাপ দিন",
                        color = fg, fontSize = 14.sp
                    )
                }
            }
            if (reached) Text("✔ লক্ষ্য পূর্ণ হয়েছে", color = Green, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TextButton({ if (count > 0) store.set(cat, "count", count - 1) }) { Text("১ কমান") }
                TextButton({ store.set(cat, "count", 0) }) { Text("আবার শুরু") }
            }
        }
    }
}
