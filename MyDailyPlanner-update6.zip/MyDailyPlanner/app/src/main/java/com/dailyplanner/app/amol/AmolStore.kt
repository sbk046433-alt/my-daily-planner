package com.dailyplanner.app.amol

import android.content.Context
import androidx.compose.runtime.mutableStateMapOf
import java.time.LocalDate

/** আজকের গণনা সংরক্ষণ। নতুন দিনে গণনা আবার শূন্য থেকে শুরু হয়। */
class AmolStore(context: Context) {
    private val prefs = context.getSharedPreferences("amol_counts", Context.MODE_PRIVATE)
    private val today = LocalDate.now().toString()
    private val counts = mutableStateMapOf<String, Int>()

    init {
        val editor = prefs.edit()
        prefs.all.forEach { (k, v) ->
            if (k.startsWith("$today|")) {
                (v as? Int)?.let { counts[k] = it }
            } else {
                editor.remove(k) // পুরোনো দিনের তথ্য মুছে ফেলা
            }
        }
        editor.apply()
    }

    private fun key(cat: String, id: String) = "$today|$cat|$id"

    fun get(cat: String, id: String): Int = counts[key(cat, id)] ?: 0

    fun set(cat: String, id: String, value: Int) {
        val k = key(cat, id)
        counts[k] = value
        prefs.edit().putInt(k, value).apply()
    }
}
