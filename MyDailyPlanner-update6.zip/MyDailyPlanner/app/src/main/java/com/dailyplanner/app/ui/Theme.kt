package com.dailyplanner.app.ui

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density

val Green = Color(0xFF2E9E5B)
val Red = Color(0xFFE03131)
val Orange = Color(0xFFF08C00)
val Blue = Color(0xFF4263EB)

class Palette(
    val name: String,
    val light: Color,
    val lightContainer: Color,
    val onLightContainer: Color,
    val dark: Color,
    val darkContainer: Color,
    val onDarkContainer: Color,
)

val palettes = listOf(
    Palette("নীল", Color(0xFF4263EB), Color(0xFFDBE4FF), Color(0xFF1B2A7A), Color(0xFF91A7FF), Color(0xFF2B3A8C), Color(0xFFDBE4FF)),
    Palette("সবুজ", Color(0xFF2B8A3E), Color(0xFFD3F9D8), Color(0xFF0B3D1A), Color(0xFF69DB7C), Color(0xFF1B5E2C), Color(0xFFD3F9D8)),
    Palette("বেগুনি", Color(0xFF7048E8), Color(0xFFE5DBFF), Color(0xFF2E1A75), Color(0xFFB197FC), Color(0xFF4527A0), Color(0xFFE5DBFF)),
    Palette("কমলা", Color(0xFFE8590C), Color(0xFFFFE8CC), Color(0xFF6B2400), Color(0xFFFFA94D), Color(0xFF8A3A00), Color(0xFFFFE8CC)),
    Palette("গোলাপি", Color(0xFFD6336C), Color(0xFFFFDEEB), Color(0xFF6B0F32), Color(0xFFF783AC), Color(0xFF8A1F4A), Color(0xFFFFDEEB)),
    Palette("টিল", Color(0xFF0C8599), Color(0xFFC5F6FA), Color(0xFF04414B), Color(0xFF3BC9DB), Color(0xFF0B5C69), Color(0xFFC5F6FA)),
)

/** হোমের হেডারের মতো জায়গায় ব্যবহারের জন্য বর্তমান থিমের মূল রঙ */
val LocalAccent = staticCompositionLocalOf { Color(0xFF4263EB) }

private fun scheme(p: Palette, dark: Boolean, amoled: Boolean): ColorScheme =
    if (!dark) {
        lightColorScheme(
            primary = p.light,
            onPrimary = Color.White,
            primaryContainer = p.lightContainer,
            onPrimaryContainer = p.onLightContainer,
            secondary = Color(0xFF2E9E5B),
            background = Color(0xFFF6F7FB),
            surface = Color.White,
            surfaceVariant = Color(0xFFEEF0F7),
        )
    } else {
        darkColorScheme(
            primary = p.dark,
            onPrimary = Color(0xFF101218),
            primaryContainer = p.darkContainer,
            onPrimaryContainer = p.onDarkContainer,
            secondary = Color(0xFF51CF66),
            background = if (amoled) Color.Black else Color(0xFF101218),
            surface = if (amoled) Color(0xFF0A0A0A) else Color(0xFF1A1D26),
            surfaceVariant = if (amoled) Color(0xFF1C1C1C) else Color(0xFF252936),
        )
    }

val textScales = listOf("স্বাভাবিক" to 1.0f, "বড়" to 1.2f, "আরও বড়" to 1.4f, "অনেক বড়" to 1.6f)

fun textScaleOf(idx: Int): Float = textScales[idx.coerceIn(0, textScales.lastIndex)].second

/** বর্তমান থিম ডার্ক কিনা (অ্যাপের নিজস্ব সেটিং অনুযায়ী) */
@Composable
fun isDarkTheme(): Boolean = MaterialTheme.colorScheme.surface.luminance() < 0.5f

@Composable
fun PlannerTheme(
    dark: Boolean,
    accent: Int = 0,
    amoled: Boolean = false,
    textScale: Float = 1f,
    content: @Composable () -> Unit
) {
    val p = palettes[accent.coerceIn(0, palettes.lastIndex)]
    val d = LocalDensity.current
    CompositionLocalProvider(
        LocalAccent provides p.light,
        LocalDensity provides Density(d.density, d.fontScale * textScale)
    ) {
        MaterialTheme(colorScheme = scheme(p, dark, amoled), content = content)
    }
}

fun priorityLabel(p: Int) = when (p) {
    0 -> "জরুরি"
    1 -> "গুরুত্বপূর্ণ"
    else -> "সাধারণ"
}

fun priorityColor(p: Int) = when (p) {
    0 -> Red
    1 -> Orange
    else -> Blue
}
