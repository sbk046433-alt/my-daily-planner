@file:OptIn(ExperimentalMaterial3Api::class)

package com.dailyplanner.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings as AndroidSettings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.dailyplanner.app.Settings
import com.dailyplanner.app.alarm.AlarmScheduler
import com.dailyplanner.app.data.Task
import com.dailyplanner.app.util.Bn
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalDateTime

/** নোটিফিকেশন ও এক্স্যাক্ট অ্যালার্ম পারমিশন না থাকলে সতর্কবার্তা */
@Composable
fun PermissionBanners(onRequestNotif: () -> Unit) {
    val ctx = LocalContext.current
    var notifOk by remember { mutableStateOf(true) }
    var exactOk by remember { mutableStateOf(true) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        notifOk = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        exactOk = AlarmScheduler.canScheduleExact(ctx)
    }
    if (!notifOk) {
        WarnCard("অ্যালার্ম দেখাতে নোটিফিকেশনের অনুমতি দরকার", "অনুমতি দিন", onRequestNotif)
    }
    var fullScreenOk by remember { mutableStateOf(true) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        fullScreenOk = Build.VERSION.SDK_INT < 34 ||
            ctx.getSystemService(android.app.NotificationManager::class.java).canUseFullScreenIntent()
    }
    if (!fullScreenOk) {
        WarnCard("অ্যালার্ম বাজলে স্ক্রিনে রিমাইন্ডার দেখাতে “ফুল স্ক্রিন নোটিফিকেশন” অনুমতি দরকার", "অনুমতি দিন") {
            if (Build.VERSION.SDK_INT >= 34) {
                ctx.startActivity(
                    Intent(AndroidSettings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }
    }
    if (!exactOk) {
        WarnCard("ঠিক সময়ে অ্যালার্ম বাজাতে “অ্যালার্ম ও রিমাইন্ডার” অনুমতি দরকার", "সেটিংস খুলুন") {
            if (Build.VERSION.SDK_INT >= 31) {
                ctx.startActivity(
                    Intent(AndroidSettings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }
    }
}

@Composable
private fun WarnCard(text: String, button: String, onClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Orange.copy(alpha = 0.15f)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text(text, Modifier.weight(1f), fontSize = 13.sp)
            TextButton(onClick) { Text(button) }
        }
    }
}

@Composable
fun HomeScreen(
    allTasks: List<Task>,
    settings: Settings,
    actions: Actions,
    onPlanTomorrow: () -> Unit,
    onRequestNotif: () -> Unit,
) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(15_000)
        }
    }
    val today = now.toLocalDate()
    val todayEpoch = today.toEpochDay()
    val todayTasks = allTasks.filter { it.dateEpochDay == todayEpoch }
    val total = todayTasks.size
    val done = todayTasks.count { it.isDone }
    val left = total - done
    val percent = if (total == 0) 0 else done * 100 / total
    val nowMin = now.hour * 60 + now.minute
    val next = todayTasks.filter { !it.isDone && it.startMinutes >= nowMin }.minByOrNull { it.startMinutes }
    val tomorrowCount = allTasks.count { it.dateEpochDay == todayEpoch + 1 }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.linearGradient(
                            listOf(LocalAccent.current, lerp(LocalAccent.current, Color.Black, 0.35f))
                        ),
                        RoundedCornerShape(24.dp)
                    )
                    .padding(20.dp)
            ) {
                Text("আমার দৈনিক পরিকল্পনা", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                Text(Bn.weekday(today), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text(Bn.gregorian(today), color = Color.White, fontSize = 15.sp)
                if (settings.showBanglaDate) {
                    Text(Bn.banglaDate(today), color = Color.White.copy(alpha = 0.9f), fontSize = 15.sp)
                }
                Text(
                    Bn.time(nowMin),
                    color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
        item { PermissionBanners(onRequestNotif) }
        item {
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surface)) {
                Row(Modifier.padding(16.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    ProgressRing(
                        percent, trackColor = MaterialTheme.colorScheme.surfaceVariant,
                        color = Green, textColor = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("আজকের অগ্রগতি", fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatBox("মোট", total, Blue, Modifier.weight(1f))
                            StatBox("সম্পন্ন", done, Green, Modifier.weight(1f))
                            StatBox("বাকি", left, Orange, Modifier.weight(1f))
                        }
                    }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp)) {
                    Text("পরবর্তী কাজ", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    if (next != null) {
                        Text(
                            next.title, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(Bn.time(next.startMinutes), color = MaterialTheme.colorScheme.onPrimaryContainer)
                    } else {
                        Text(
                            if (total == 0) "আজ কোনো কাজ নেই" else "আজকের আর কোনো নির্ধারিত কাজ বাকি নেই",
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("আগামীকালের কাজ: ${Bn.num(tomorrowCount)} টি", fontWeight = FontWeight.SemiBold)
                    Button(onPlanTomorrow, Modifier.fillMaxWidth()) { Text("আগামীকালের পরিকল্পনা তৈরি করুন") }
                }
            }
        }
        item { SectionTitle("আজকের কাজ") }
        dayTasks(
            todayTasks, actions,
            onAdd = { actions.add(todayEpoch) },
            onCopy = null,
            emptyText = "আজকের জন্য কোনো কাজ নেই। নতুন কাজ যোগ করুন।"
        )
    }
}
