@file:OptIn(ExperimentalMaterial3Api::class)

package com.dailyplanner.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Book
import com.dailyplanner.app.amol.AmolScreen
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings as SettingsIcon
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.dailyplanner.app.ui.Actions
import com.dailyplanner.app.ui.CalendarScreen
import com.dailyplanner.app.ui.DayPlanScreen
import com.dailyplanner.app.ui.HomeScreen
import com.dailyplanner.app.ui.PlannerTheme
import com.dailyplanner.app.ui.ReportScreen
import com.dailyplanner.app.ui.SettingsScreen
import com.dailyplanner.app.ui.textScaleOf
import com.dailyplanner.app.ui.TaskEditorScreen
import java.time.LocalDate

class MainActivity : ComponentActivity() {
    private val vm: PlannerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val settings = planner.settings
        setContent {
            val dark = when (settings.darkMode) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }
            PlannerTheme(dark, settings.accent, settings.amoled, textScaleOf(settings.textScaleIdx)) {
                Surface { PlannerRoot(vm, settings) }
            }
        }
    }
}

private const val NONE = -1L

@Composable
private fun PlannerRoot(vm: PlannerViewModel, settings: Settings) {
    val tasks by vm.tasks.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    // সম্পাদক: editorTaskId = NONE (বন্ধ), 0 (নতুন), >0 (সম্পাদনা)
    var editorTaskId by rememberSaveable { mutableLongStateOf(NONE) }
    var editorDay by rememberSaveable { mutableLongStateOf(0L) }
    // দিনের পরিকল্পনা পর্দা: NONE = বন্ধ
    var planDay by rememberSaveable { mutableLongStateOf(NONE) }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val requestNotif: () -> Unit = {
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) { requestNotif() }

    val actions = Actions(
        toggle = { vm.toggle(it) },
        delete = { vm.delete(it) },
        edit = { editorTaskId = it.id; editorDay = it.dateEpochDay },
        add = { day -> editorTaskId = 0L; editorDay = day },
        copy = { list, day -> vm.copyTo(list, day) },
    )

    BackHandler(enabled = editorTaskId != NONE) { editorTaskId = NONE }
    BackHandler(enabled = editorTaskId == NONE && planDay != NONE) { planDay = NONE }
    BackHandler(enabled = editorTaskId == NONE && planDay == NONE && tab != 0) { tab = 0 }

    when {
        editorTaskId != NONE -> {
            val existing = if (editorTaskId > 0) tasks.firstOrNull { it.id == editorTaskId } else null
            TaskEditorScreen(
                existing = existing,
                defaultDay = editorDay,
                defaultPreAlert = settings.defaultPreAlert,
                onSave = { vm.save(it) },
                onClose = { editorTaskId = NONE },
            )
        }
        planDay != NONE -> DayPlanScreen(planDay, tasks, actions) { planDay = NONE }
        else -> {
            Scaffold(
                bottomBar = {
                    NavigationBar {
                        val items = listOf(
                            "হোম" to Icons.Filled.Home,
                            "ক্যালেন্ডার" to Icons.Filled.CalendarMonth,
                            "আমল" to Icons.Filled.Book,
                            "রিপোর্ট" to Icons.Filled.BarChart,
                            "সেটিংস" to Icons.Filled.SettingsIcon,
                        )
                        items.forEachIndexed { i, (label, icon) ->
                            NavigationBarItem(
                                selected = tab == i, onClick = { tab = i },
                                icon = { Icon(icon, label) }, label = { Text(label) }
                            )
                        }
                    }
                },
                floatingActionButton = {
                    if (tab == 0 || tab == 1) {
                        FloatingActionButton(onClick = { actions.add(LocalDate.now().toEpochDay()) }) {
                            Icon(Icons.Filled.Add, "নতুন কাজ")
                        }
                    }
                }
            ) { pad ->
                androidx.compose.foundation.layout.Box(Modifier.padding(pad)) {
                    when (tab) {
                        0 -> HomeScreen(
                            tasks, settings, actions,
                            onPlanTomorrow = { planDay = LocalDate.now().toEpochDay() + 1 },
                            onRequestNotif = requestNotif
                        )
                        1 -> CalendarScreen(tasks, settings, actions)
                        2 -> AmolScreen()
                        3 -> ReportScreen(tasks)
                        else -> SettingsScreen(settings, requestNotif)
                    }
                }
            }
        }
    }
}
