package com.dailyplanner.app.alarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import androidx.core.app.NotificationCompat
import com.dailyplanner.app.MainActivity
import com.dailyplanner.app.R
import com.dailyplanner.app.Settings
import com.dailyplanner.app.data.Task
import com.dailyplanner.app.util.Bn

object Notifier {
    const val ACTION_DONE = "com.dailyplanner.app.DONE"
    const val ACTION_SNOOZE = "com.dailyplanner.app.SNOOZE"
    const val ACTION_DISMISS = "com.dailyplanner.app.DISMISS"
    private const val PRE_CHANNEL = "task_prealert"

    private fun alarmChannel(s: Settings) = "task_alarm_v${s.channelVersion}"

    private fun soundUri(s: Settings): Uri =
        if (s.soundUri.isNotEmpty()) Uri.parse(s.soundUri)
        else RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

    fun ensureChannels(ctx: Context, s: Settings) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        // পুরোনো শব্দের চ্যানেল মুছে ফেলা
        nm.notificationChannels
            .filter { it.id.startsWith("task_alarm_v") && it.id != alarmChannel(s) }
            .forEach { nm.deleteNotificationChannel(it.id) }

        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val alarm = NotificationChannel(alarmChannel(s), "কাজের অ্যালার্ম", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "নির্ধারিত সময়ে কাজের অ্যালার্ম"
            setSound(soundUri(s), attrs)
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 500, 300, 500, 300, 800)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        val pre = NotificationChannel(PRE_CHANNEL, "আগাম সতর্কবার্তা", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "অ্যালার্মের আগে সতর্কবার্তা"
        }
        nm.createNotificationChannel(alarm)
        nm.createNotificationChannel(pre)
    }

    private fun actionIntent(ctx: Context, id: Long, action: String): PendingIntent {
        val i = Intent(ctx, ActionReceiver::class.java).apply {
            this.action = action
            data = Uri.parse("planner://action/$id/$action")
            putExtra(AlarmScheduler.EXTRA_TASK_ID, id)
        }
        return PendingIntent.getBroadcast(
            ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun show(ctx: Context, s: Settings, task: Task, isPre: Boolean) {
        ensureChannels(ctx, s)
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val timeText = if (task.startMinutes >= 0) Bn.time(task.startMinutes) else ""
        val title = if (isPre) "শীঘ্রই: ${task.title}" else task.title
        val text = if (isPre) "${Bn.num(task.preAlertMinutes)} মিনিট পরে শুরু ($timeText)"
        else "এখন কাজের সময় ($timeText)"

        val b = NotificationCompat.Builder(ctx, if (isPre) PRE_CHANNEL else alarmChannel(s))
            .setSmallIcon(R.drawable.ic_stat_task)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText(if (task.description.isBlank()) text else "$text\n${task.description}")
            )
            .setContentIntent(open)
            .setAutoCancel(!isPre)
            .setCategory(if (isPre) NotificationCompat.CATEGORY_REMINDER else NotificationCompat.CATEGORY_ALARM)
            .setPriority(if (isPre) NotificationCompat.PRIORITY_DEFAULT else NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)

        if (!isPre) {
            // লক স্ক্রিন বা স্ক্রিন বন্ধ থাকলে পুরো পর্দায় অ্যালার্ম দেখাবে
            val screen = PendingIntent.getActivity(
                ctx, 0,
                Intent(ctx, AlarmActivity::class.java).apply {
                    data = Uri.parse("planner://alarmscreen/${task.id}")
                    putExtra(AlarmScheduler.EXTRA_TASK_ID, task.id)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            b.setFullScreenIntent(screen, true)
            b.setContentIntent(screen)
            b.addAction(0, "সম্পন্ন", actionIntent(ctx, task.id, ACTION_DONE))
            b.addAction(0, "স্থগিত (${Bn.num(s.snoozeMinutes)} মি.)", actionIntent(ctx, task.id, ACTION_SNOOZE))
            b.addAction(0, "বাতিল", actionIntent(ctx, task.id, ACTION_DISMISS))
        }
        val n = b.build()
        // অ্যালার্ম নোটিফিকেশন বন্ধ না করা পর্যন্ত শব্দ চলতে থাকবে
        if (!isPre) n.flags = n.flags or Notification.FLAG_INSISTENT
        nm.notify(notifId(task.id, isPre), n)
    }

    private fun notifId(taskId: Long, pre: Boolean): Int = (taskId.toInt() * 2) + if (pre) 1 else 0

    fun cancel(ctx: Context, taskId: Long) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.cancel(notifId(taskId, false))
        nm.cancel(notifId(taskId, true))
    }
}
